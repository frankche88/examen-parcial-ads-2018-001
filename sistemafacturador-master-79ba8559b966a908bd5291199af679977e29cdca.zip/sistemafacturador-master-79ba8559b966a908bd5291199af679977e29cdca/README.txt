Compilar y empaquetar

setear la variable de entorno JAVA_HOME con el JDK 8

export JAVA_HOME=/d/program\ files/java/jdk1.8.0_45


Modificar el archivo: gradle.properties

systemProp.https.proxyUser=tu_usuario_red
systemProp.http.proxyUser=tu_usuario_red


Ejecutar:

gradle build && "$JAVA_HOME"/bin/java -jar build/libs/sistemaFactutador-0.1.0-SNAPSHOT-all.jar server src/main/resources/prod.yaml


Probar:

curl -s localhost:9000/employees; echo






