package sistema.facturador.persistence;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.NotBlank;

import javax.persistence.*;

import static javax.persistence.GenerationType.AUTO;

@Getter
@Setter
@Entity
@Table(name = "employee")
public class Employee {

  @Id
  @Column(name = "id")
  @GeneratedValue(strategy = AUTO)
  private Integer id;

  @Column(name = "fistName")
  @NotBlank
  private String firstName;

  @Column(name = "lastName")
  @NotBlank
  private String lastName;

  @Column(name = "dept")
  private String dept;
}
