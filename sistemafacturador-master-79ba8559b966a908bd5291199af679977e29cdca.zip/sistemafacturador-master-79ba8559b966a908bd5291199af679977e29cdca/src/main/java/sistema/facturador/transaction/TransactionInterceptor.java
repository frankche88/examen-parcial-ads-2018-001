package sistema.facturador.transaction;

import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A simple transaction interceptor which registers an entity manager in a ThreadLocal and unregisters after the
 * method was called.
 * It does not support any kind of context propagation. If a transactional method calls another's bean transactional
 * method a new entity manager is created and added to the stack.
 */
@Interceptor
@Transactional
public class TransactionInterceptor {

  private Logger logger = LoggerFactory.getLogger(TransactionInterceptor.class);

  @AroundInvoke
  public Object runInTransaction(InvocationContext invocationContext) throws Exception {

    

    Object result = null;
    try {
      logger.info("Beginning transaction");
      //em.getConnection(). .getTransaction().begin();

      result = invocationContext.proceed();

      //em.getTransaction().commit();
      logger.info("Transaction committed");
    } catch (Throwable e) {
      
      throw e;
    } finally {
      
    }


    return result;
  }
}
