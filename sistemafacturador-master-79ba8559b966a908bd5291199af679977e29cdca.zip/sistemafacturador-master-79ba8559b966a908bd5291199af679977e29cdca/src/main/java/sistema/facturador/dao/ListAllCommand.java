package sistema.facturador.dao;

import java.util.Collections;
import java.util.List;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;

import lombok.extern.slf4j.Slf4j;
import sistema.facturador.persistence.Employee;

@Slf4j
public class ListAllCommand extends HystrixCommand<List<Employee>> {


private final EmployeeDao dao;

  public ListAllCommand(EmployeeDao employeeDao) {
    super(Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey("DatabaseGroup")));

    this.dao = employeeDao;
  }

  @Override
  protected List<Employee> run() throws Exception {
    //incorrecto poner codigo aplicativo
    return dao.findAll();
  }

  @Override
  protected List<Employee> getFallback() {
    log.error("Problemas al consultar la base de datos");

    return Collections.emptyList();
  }
}
