package sistema.facturador.dao;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import lombok.extern.slf4j.Slf4j;
import sistema.facturador.mybatis.mappers.Ping;
import sistema.facturador.persistence.Employee;

@Slf4j
public class EmployeeDao {

    @Inject
    SqlSessionFactory sqlSessionFactory;

    public Employee save(final Employee object) {
        // try {
        //
        //// entityManager.get().persist(object);
        //// entityManager.get().flush();
        //
        // } catch (javax.validation.ConstraintViolationException violation) {
        // throw new ValidationException(violation);
        // }

        return object;
    }

    private SqlSession session() {

        return sqlSessionFactory.openSession();
    }

    public Employee findById(final Integer id) {

        Ping mapper = session().getMapper(Ping.class);

        mapper.ping();

        return new Employee();
    }

    public List<Employee> findAll() {
        Ping mapper = session().getMapper(Ping.class);

        mapper.ping();

        return new ArrayList<>();
    }

    public List<Employee> find(Integer pageNumber, Integer pageSize) {
        
        log.debug("PageNumber {}", pageNumber);
        
        log.debug("pageSize   {}", pageSize);
        
        Ping mapper = session().getMapper(Ping.class);

        mapper.ping();
        
        return new ArrayList<>();
    }

    public void delete(final Employee object) {
        Ping mapper = session().getMapper(Ping.class);

        mapper.ping();
    }

    
    public void deleteById(final Integer id) {
        
        Ping mapper = session().getMapper(Ping.class);

        mapper.ping();
        
    }

}
