package sistema.facturador.service;

import java.util.List;

import javax.inject.Inject;

import sistema.facturador.dao.EmployeeDao;
import sistema.facturador.dao.ListAllCommand;
import sistema.facturador.persistence.Employee;

public class EmployeeService {
    
    @Inject
    private EmployeeDao employeeDao;

//    @Inject
//    private CamelContext context;

    public List<Employee> findAll() {
        return employeeDao.findAll();
    }

    public List<Employee> findAllInResilienceMode() {
        return new ListAllCommand(employeeDao).execute();
    }

    public Employee createEmployee(Employee employee) {
        return employeeDao.save(employee);
    }

//    public String longProcess(String data) {
//        ProducerTemplate template = context.createProducerTemplate();
//        return template.requestBody("direct:longProcess", data).toString();
//    }
}
