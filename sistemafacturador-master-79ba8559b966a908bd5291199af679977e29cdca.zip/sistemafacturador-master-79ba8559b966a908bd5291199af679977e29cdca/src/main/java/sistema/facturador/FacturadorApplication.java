package sistema.facturador;

import javax.enterprise.context.ApplicationScoped;

import com.codahale.metrics.health.HealthCheck;

import io.dropwizard.Application;
import io.dropwizard.Configuration;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import sistema.facturador.config.WeldBundle;
import sistema.facturador.resources.EmployeeResource;

@ApplicationScoped
public class FacturadorApplication extends Application<Configuration> {

    @Override
    public void run(final Configuration config, final Environment environment) throws Exception {

        environment.healthChecks().register("dummy", new HealthCheck() {
            @Override
            protected Result check() throws Exception {

                return Result.healthy("dummy");
            }
        });

        // environment.healthChecks().register("db", new HealthCheck() {
        // @Override
        // protected Result check() throws Exception {
        // //query a la base
        // return Result.healthy("YOLO");
        // }
        // });

        // environment.jersey().register(TestFilter.class);

        environment.jersey().register(EmployeeResource.class);

    }

    @Override
    public void initialize(final Bootstrap<Configuration> bootstrap) {
        // Weld (CDI) support
        bootstrap.addBundle(new WeldBundle());
    }

    public static void main(String... params) throws Exception {
        new FacturadorApplication().run(params);
    }

}
