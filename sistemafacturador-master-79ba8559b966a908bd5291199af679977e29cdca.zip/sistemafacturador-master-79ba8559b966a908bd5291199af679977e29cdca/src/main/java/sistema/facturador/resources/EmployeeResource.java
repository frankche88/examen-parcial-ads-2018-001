package sistema.facturador.resources;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static javax.ws.rs.core.Response.created;
import static sistema.facturador.resources.UriHelper.getUriForId;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import javax.inject.Inject;
import javax.validation.constraints.Max;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import sistema.facturador.dao.EmployeeDao;
import sistema.facturador.persistence.Employee;
import sistema.facturador.service.EmployeeService;

@Path(EmployeeResource.EMPLOYEE_PATH)
@Produces(value = APPLICATION_JSON)
//@Transactional
public class EmployeeResource {

    public static final String EMPLOYEE_PATH = "/employees";

    //@Inject
    private EmployeeService employeeService;

    @Inject
    private EmployeeDao employeeDao;

    @POST
    public Response create(Employee employee, @Context UriInfo uriInfo) throws URISyntaxException {
        Employee savedEmployee = employeeService.createEmployee(employee);

        URI uri = getUriForId(uriInfo, savedEmployee.getId());

        return created(uri).entity(savedEmployee).build();
    }

    @GET
    @Path("/listMalo")
    public List<Employee> listMalo() {
        return employeeService.findAll();
    }

    @GET
    @Path("/list")
    public List<Employee> listResilience() {
        return employeeService.findAllInResilienceMode();
    }

    @GET
    public List<Employee> list(@QueryParam("page") @DefaultValue("1") Integer pageNum,
            @QueryParam("size") @DefaultValue("100") @Max(100) Integer pageSize) {

        return employeeDao.find(pageNum, pageSize);
    }

    @GET
    @Path("/{id}")
    public Employee get(@PathParam("id") Integer id) {
        return employeeDao.findById(id);
    }

//    @PUT
//    @Path("/longProcess/{data}")
//    public Response longProcess(@PathParam("data") String data) {
//        return Response.accepted(employeeService.longProcess(data)).build();
//    }
}
