package com.tidyjava.example.usecases.listActivities;

import com.tidyjava.example.callback.Callback;

import java.util.List;

public interface ListActivitiesOutputBoundary extends Callback<List<ActivityDetails>> {
}
