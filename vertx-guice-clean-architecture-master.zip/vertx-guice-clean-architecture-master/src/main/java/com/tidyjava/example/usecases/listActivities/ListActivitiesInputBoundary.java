package com.tidyjava.example.usecases.listActivities;

public interface ListActivitiesInputBoundary {
    void listActivities(ListActivitiesOutputBoundary presenter);
}
