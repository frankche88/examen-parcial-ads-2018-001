package com.tidyjava.example.usecases.listActivities;

public class ActivityDetails {
    private String name;

    public ActivityDetails(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
